function getCookie(name) {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) return parts.pop().split(";").shift();
}

function fetchComAuth(url, options = {}) {
  const isFormData = options.body instanceof FormData;

  const headers = {
    ...options.headers,
  };

  if (!isFormData) {
    headers["Content-Type"] = "application/json";
  }

  const csrfToken = getCookie("csrf-token");

  if (csrfToken) {
    headers["x-csrf-token"] = csrfToken;
  }

  return fetch(url, {
    ...options,
    headers,
    credentials: "include",
  }).then(async (res) => {
    if (res.status === 401) {
      localStorage.removeItem("role");

      Swal.fire({
        icon: "warning",
        title: "Sessão expirada",
        text: "Faça login novamente.",
        confirmButtonText: "OK",
      }).then(() => {
        window.location.href = "login.html";
      });

      return;
    }

    const data = await res.json();

    if (!res.ok) {
      throw new Error(data.mensagem || "Erro na requisição");
    }

    return data;
  });
}

function mostrarLoading() {
  const el = document.getElementById("loading");
  if (el) el.style.display = "flex";
}

function esconderLoading() {
  const el = document.getElementById("loading");
  if (el) el.style.display = "none";
}

function toggleSidebar() {
  const sidebar = document.querySelector(".sidebar");

  if (!sidebar) return;

  sidebar.classList.toggle("active");
}

function setActiveMenu(button) {
  document.querySelectorAll(".sidebar-link").forEach((el) => {
    el.classList.remove("active");
  });

  if (button) button.classList.add("active");
}

function verificarSuperAdmin() {
  const role = localStorage.getItem("role");

  if (role !== "superadmin") {
    window.location.href = "admin.html";
    return;
  }

  fetchComAuth("http://localhost:3000/api/admin/check-token")
    .then((data) => {
      if (!data) return;

      carregarAdmins();
    })
    .catch((err) => {
      console.error(err);

      localStorage.removeItem("role");

      Swal.fire({
        icon: "error",
        title: "Erro",
        text: "Sua sessão é inválida.",
      }).then(() => {
        window.location.href = "login.html";
      });
    });
}

function carregarAdmins() {
  mostrarLoading();

  fetchComAuth("http://localhost:3000/api/admin/list")
    .then((data) => {
      const container = document.getElementById("listaAdmins");

      container.innerHTML = "";

      if (!data || !data.admins || data.admins.length === 0) {
        container.innerHTML =
          '<p class="empty-state">Nenhum admin cadastrado.</p>';

        return;
      }

      data.admins.forEach((admin) => {
        const status = admin.bloqueado
          ? "🔒 Bloqueado"
          : admin.active === 1
            ? "Ativo"
            : "Desativado";

        const establishmentInfo = admin.establishment_name
          ? `<br><small>${admin.establishment_name}</small>`
          : "";

        const item = document.createElement("div");

        item.classList.add("admin-item");

        item.innerHTML = `
          <div>
            <strong>${admin.email}</strong>
            <span>${admin.role} - ${status}${establishmentInfo}</span>
          </div>

          <div class="admin-actions">
            <button onclick="desbloquearAdmin(${admin.id})">
              Desbloquear
            </button>

            <button onclick="toggleAdminStatus(${admin.id}, ${admin.active === 1})">
              ${admin.active === 1 ? "Desativar" : "Reativar"}
            </button>

            <button class="secondary-btn" onclick="resetAdminPassword(${admin.id})">
              Trocar senha
            </button>
          </div>
        `;

        container.appendChild(item);
      });
    })
    .catch((err) => {
      Swal.fire({
        icon: "error",
        title: "Erro",
        text: err.message,
      });
    })
    .finally(() => {
      esconderLoading();
    });
}

function desbloquearAdmin(id) {
  Swal.fire({
    title: "Desbloquear conta?",
    text: "Isso vai permitir que o admin faça login novamente.",
    icon: "question",
    showCancelButton: true,
    confirmButtonText: "Sim, desbloquear",
    cancelButtonText: "Cancelar",
  }).then((result) => {
    if (!result.isConfirmed) return;

    fetchComAuth(`http://localhost:3000/api/admin/desbloquear/${id}`, {
      method: "PUT",
    })
      .then((data) => {
        if (!data) return;

        Swal.fire({
          icon: "success",
          title: "Sucesso",
          text: data.mensagem,
        });

        carregarAdmins();
      })
      .catch((err) => {
        Swal.fire({
          icon: "error",
          title: "Erro",
          text: err.message || "Erro ao desbloquear",
        });
      });
  });
}

function abrirModalCriarAdmin() {
  const modal = document.getElementById("modalCriarAdmin");

  if (modal) modal.classList.add("active");
}

function fecharModalAdmin(event) {
  const modal = document.getElementById("modalCriarAdmin");

  if (!modal) return;

  if (event && event.target !== modal) return;

  modal.classList.remove("active");

  limparFormularioCriarAdmin();
}

function limparFormularioCriarAdmin() {
  document.getElementById("novoAdminEmail").value = "";
  document.getElementById("novoAdminSenha").value = "";
  document.getElementById("novoAdminEstabelecimento").value = "";

  document.querySelector('input[name="role"][value="admin"]').checked = true;
}

function salvarNovoAdmin() {
  const email = document.getElementById("novoAdminEmail").value.trim();

  const senha = document.getElementById("novoAdminSenha").value.trim();

  const role = document.querySelector('input[name="role"]:checked').value;

  const establishmentName = document
    .getElementById("novoAdminEstabelecimento")
    .value.trim();

  if (!email) {
    Swal.fire({
      icon: "warning",
      title: "Campo obrigatório",
      text: "Preencha o email.",
    });

    return;
  }

  if (!senha) {
    Swal.fire({
      icon: "warning",
      title: "Campo obrigatório",
      text: "Preencha a senha.",
    });

    return;
  }

  if (role === "admin" && !establishmentName) {
    Swal.fire({
      icon: "warning",
      title: "Campo obrigatório",
      text: "Preencha o nome do estabelecimento.",
    });

    return;
  }

  fetchComAuth("http://localhost:3000/api/admin/register", {
    method: "POST",

    body: JSON.stringify({
      email,
      senha,
      role,
      establishmentName: role === "admin" ? establishmentName : null,
    }),
  })
    .then((data) => {
      if (!data) return;

      Swal.fire({
        icon: "success",
        title: "Sucesso",
        text: data.mensagem,
      });

      fecharModalAdmin(null);

      carregarAdmins();
    })
    .catch((err) => {
      Swal.fire({
        icon: "error",
        title: "Erro",
        text: err.message,
      });
    });
}

function resetAdminPassword(id) {
  Swal.fire({
    title: "Redefinir senha",
    input: "password",
    inputLabel: "Digite a nova senha temporária",
    inputPlaceholder: "Senha temporária",

    inputAttributes: {
      autocapitalize: "off",
      autocorrect: "off",
    },

    showCancelButton: true,
    confirmButtonText: "Salvar",
    cancelButtonText: "Cancelar",

    preConfirm: (value) => {
      if (!value || value.trim().length < 8) {
        Swal.showValidationMessage("A senha deve ter pelo menos 8 caracteres.");
      }

      return value;
    },
  }).then((result) => {
    if (!result.isConfirmed) return;

    fetchComAuth(`http://localhost:3000/api/admin/${id}/reset-password`, {
      method: "PUT",

      body: JSON.stringify({
        senha: result.value.trim(),
      }),
    })
      .then((data) => {
        if (!data) return;

        Swal.fire({
          icon: "success",
          title: "Sucesso",
          text: data.mensagem,
        });

        carregarAdmins();
      })
      .catch((err) => {
        Swal.fire({
          icon: "error",
          title: "Erro",
          text: err.message || "Falha ao redefinir senha.",
        });
      });
  });
}

function toggleAdminStatus(id, currentlyActive) {
  fetchComAuth(`http://localhost:3000/api/admin/${id}/status`, {
    method: "PATCH",

    body: JSON.stringify({
      active: !currentlyActive,
    }),
  })
    .then((data) => {
      if (!data) return;

      Swal.fire({
        icon: "success",
        title: "Sucesso",
        text: data.mensagem,
      });

      carregarAdmins();
    })
    .catch((err) => {
      Swal.fire({
        icon: "error",
        title: "Erro",
        text: err.message,
      });
    });
}

window.onload = () => {
  verificarSuperAdmin();
};

// ==================== LOGOUT ====================

function logout() {
  Swal.fire({
    title: "Sair do sistema?",
    text: "Você precisará fazer login novamente.",
    icon: "question",
    showCancelButton: true,
    confirmButtonText: "Sim, sair",
    cancelButtonText: "Cancelar",
  }).then((result) => {
    if (!result.isConfirmed) return;

    fetch("http://localhost:3000/api/admin/logout", {
      method: "POST",
      credentials: "include",
    }).finally(() => {
      localStorage.removeItem("role");
      localStorage.removeItem("establishmentId");
      localStorage.removeItem("establishmentName");

      Swal.fire({
        title: "Saindo...",
        allowOutsideClick: false,

        didOpen: () => {
          Swal.showLoading();
        },
      });

      setTimeout(() => {
        window.location.href = "login.html";
      }, 1000);
    });
  });
}
