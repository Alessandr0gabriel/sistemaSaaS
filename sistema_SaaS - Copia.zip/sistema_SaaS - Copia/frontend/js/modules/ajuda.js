export function exibirFromAjuda() {
  const lista = document.getElementById("listarPedidos");

  if (!lista) return;

  lista.innerHTML = `
    <div class="ajuda-container">
      <h2>Precisa de ajuda?</h2>
      <p>Fale com nosso suporte 👇</p>

      <a 
        href="https://wa.me/5544997454394?text=Ol%C3%A1,%20preciso%20de%20ajuda%20no%20sistema" 
        target="_blank"
        class="btn-whatsapp"
      >
        💬 Falar no WhatsApp
      </a>
    </div>
  `;
}
