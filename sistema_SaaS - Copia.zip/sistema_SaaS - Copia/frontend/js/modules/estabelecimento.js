import { API_URL } from "../core/config.js";
import { fetchComAuth } from "../core/api.js";
import { showError, showSuccess, showToast } from "../ui/alerts.js";

export async function carregarEstabelecimento() {
  const establishmentId = localStorage.getItem("establishmentId");
  const establishmentName = localStorage.getItem("establishmentName");
  const establishmentNameEl = document.getElementById("establishmentName");
  const sidebarName = document.getElementById("sidebarEstablishmentName");
  const brandIcon = document.getElementById("brandIcon");

  if (establishmentName) {
    if (establishmentNameEl)
      establishmentNameEl.textContent = establishmentName;
    if (sidebarName) sidebarName.textContent = establishmentName;
    if (brandIcon)
      brandIcon.textContent = establishmentName.charAt(0).toUpperCase();
    return;
  }

  if (!establishmentId) {
    if (establishmentNameEl)
      establishmentNameEl.textContent = "Estabelecimento não encontrado";
    if (sidebarName) sidebarName.textContent = "Sem estabelecimento";
    return;
  }

  try {
    const data = await fetch(`${API_URL}/estabelecimentos/${establishmentId}`);
    const json = await data.json();

    if (establishmentNameEl) establishmentNameEl.textContent = json.nome;
    if (sidebarName) sidebarName.textContent = json.nome;
    if (brandIcon) brandIcon.textContent = json.nome.charAt(0).toUpperCase();
    localStorage.setItem("establishmentName", json.nome);
  } catch {
    if (establishmentNameEl)
      establishmentNameEl.textContent = "Estabelecimento: carregando...";
    if (sidebarName) sidebarName.textContent = "Carregando...";
  }
}

export async function carregarURLLoja() {
  const establishmentId = localStorage.getItem("establishmentId");
  const urlLojaInput = document.getElementById("urlLoja");

  if (!establishmentId) {
    if (urlLojaInput) urlLojaInput.value = "";
    return;
  }

  try {
    const data = await fetchComAuth(
      `${API_URL}/estabelecimentos/${establishmentId}`,
    );
    if (urlLojaInput) {
      urlLojaInput.value = `http://127.0.0.1:5500/frontend/html/index.html?estab=${data.slug}`;
    }
  } catch (err) {
    console.error("Erro ao carregar URL da loja:", err);
    if (urlLojaInput) urlLojaInput.value = "";
  }
}

export function copiarURL() {
  const input = document.getElementById("urlLoja");
  if (!input) return;

  input.select();
  navigator.clipboard.writeText(input.value);

  showToast("success", "Link copiado!");
}

export async function salvarDados() {
  const telefone = document.getElementById("inputTelefone")?.value;
  const establishmentId = localStorage.getItem("establishmentId");

  try {
    await fetchComAuth(`${API_URL}/estabelecimentos/${establishmentId}/dados`, {
      method: "PUT",
      body: JSON.stringify({ telefone }),
    });

    showSuccess("Dados atualizados com sucesso!", "");
  } catch (err) {
    console.error(err);
    showError("Erro ao salvar dados", err.message || "");
  }

  const modal = document.getElementById("modalDados");
  if (modal) modal.classList.remove("active");
}

export async function carregarDadosEstabelecimento() {
  try {
    const estab = await fetchComAuth(`${API_URL}/admin/me/estabelecimento`);
    const inputTelefone = document.getElementById("inputTelefone");
    if (inputTelefone) inputTelefone.value = estab.telefone || "";
  } catch (err) {
    console.error("Erro ao buscar dados", err);
  }
}
