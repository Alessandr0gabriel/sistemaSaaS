import { API_URL } from "../core/config.js";
import { fetchComAuth } from "../core/api.js";
import { definirDatasPadrao } from "../ui/tabs.js";
import { showError } from "../ui/alerts.js";

export async function carregarFaturamento() {
  try {
    const data = await fetchComAuth(`${API_URL}/admin/faturamento`);
    const total = Number(data.faturamento_hoje || 0).toFixed(2);
    const faturamentoEl = document.getElementById("mediaFaturamento");
    if (faturamentoEl) {
      faturamentoEl.textContent = `R$ ${total}`;
    }
  } catch (err) {
    console.error("Erro ao carregar faturamento:", err);
    const faturamentoEl = document.getElementById("mediaFaturamento");
    if (faturamentoEl) {
      faturamentoEl.textContent = "R$ 0,00";
    }
  }
}

export async function carregarFaturamentoTela() {
  const lista = document.getElementById("listarPedidos");
  if (!lista) return;

  lista.innerHTML = "<p class='empty-state'>Carregando faturamento...</p>";

  try {
    const data = await fetchComAuth(`${API_URL}/admin/faturamento`);
    const total = Number(data.faturamento_total || 0).toFixed(2);
    const semana = Number(data.faturamento_semana || 0).toFixed(2);
    const mes = Number(data.faturamento_mes || 0).toFixed(2);

    lista.innerHTML = `
      <div class="filtro-data">
        <div class="input-group">
          <label>Data inicial</label>
          <input type="date" id="dataInicio" />
        </div>

        <div class="input-group">
          <label>Data final</label>
          <input type="date" id="dataFim" />
        </div>

        <button class="primary-btn" onclick="filtrarFaturamento()">Filtrar</button>
      </div>

      <div class="faturamento-tabs">
        <button class="tab-button active" data-tab="total" onclick="setFaturamentoTab('total')">Total</button>
        <button class="tab-button" data-tab="semana" onclick="setFaturamentoTab('semana')">Semana</button>
        <button class="tab-button" data-tab="mes" onclick="setFaturamentoTab('mes')">Mês</button>
      </div>

      <div class="tab-panels">
        <div id="tab-total" class="tab-panel active">
          <div class="faturamento-card">
            <h3>💰 Total</h3>
            <strong>R$ ${total}</strong>
            <p>Valor acumulado no histórico do estabelecimento.</p>
          </div>
        </div>
        <div id="tab-semana" class="tab-panel">
          <div class="faturamento-card">
            <h3>📅 Semana</h3>
            <strong>R$ ${semana}</strong>
            <p>Últimos 7 dias.</p>
          </div>
        </div>
        <div id="tab-mes" class="tab-panel">
          <div class="faturamento-card">
            <h3>🗓️ Mês</h3>
            <strong>R$ ${mes}</strong>
            <p>Últimos 30 dias.</p>
          </div>
        </div>
      </div>

      <div id="resultadoFaturamento" class="resultado-faturamento">
        <p>💰 Faturamento no período</p>
        <h1>R$ ${total}</h1>
      </div>
    `;

    definirDatasPadrao();
  } catch (err) {
    console.error(err);
    lista.innerHTML = "<p class='empty-state'>Erro ao carregar faturamento</p>";
  }
}

export async function filtrarFaturamento() {
  const inicio = document.getElementById("dataInicio")?.value;
  const fim = document.getElementById("dataFim")?.value;
  const container = document.getElementById("resultadoFaturamento");

  if (!inicio || !fim) {
    alert("Selecione as datas!");
    return;
  }

  if (!container) return;
  container.innerHTML = "Carregando...";

  try {
    const data = await fetchComAuth(
      `${API_URL}/admin/faturamento?inicio=${inicio}&fim=${fim}`,
    );
    const total = Number(data.faturamento_total || 0).toFixed(2);

    container.innerHTML = `
      <div class="faturamento-card">
        <h3>💰 Período selecionado</h3>
        <strong>R$ ${total}</strong>
      </div>
    `;
  } catch (err) {
    console.error(err);
    container.innerHTML = "Erro ao buscar faturamento";
  }
}
