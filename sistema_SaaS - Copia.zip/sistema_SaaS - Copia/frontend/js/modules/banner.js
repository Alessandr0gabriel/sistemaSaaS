import { API_URL } from "../core/config.js";
import { fetchComAuth } from "../core/api.js";
import { showError, showSuccess } from "../ui/alerts.js";

export async function enviarBanner() {
  const file = document.getElementById("inputBanner")?.files?.[0];
  const id = localStorage.getItem("establishmentId");

  if (!file) {
    return showError("Selecione uma imagem", "Escolha um arquivo para o banner.");
  }

  const formData = new FormData();
  formData.append("banner", file);

  try {
    await fetchComAuth(`${API_URL}/estabelecimentos/${id}/banner`, {
      method: "PUT",
      body: formData,
    });

    showSuccess("Banner atualizado!", "Seu banner foi enviado com sucesso", 2000);
    const modal = document.getElementById("modalBanner");
    if (modal) modal.classList.remove("active");
  } catch (err) {
    showError("Erro ao atualizar", err.message);
  }
}
