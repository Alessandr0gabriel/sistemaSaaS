const { initializeApp, cert, getApps } = require("firebase-admin/app");
const {
  getFirestore,
  FieldValue,
  Timestamp,
  AggregateField,
} = require("firebase-admin/firestore");
const { getAuth } = require("firebase-admin/auth");

const serviceAccount = require("./projeto-saas-uninga-firebase-adminsdk-fbsvc-88029a3dc1.json");

// Inicializa somente se ainda não existir uma instância Firebase
if (!getApps().length) {
  initializeApp({
    credential: cert(serviceAccount),
  });
}

const db = getFirestore();
const auth = getAuth();

module.exports = {
  db,
  auth,
  FieldValue,
  Timestamp,
  AggregateField,
};
