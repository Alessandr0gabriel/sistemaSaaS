const express = require("express");
const router = express.Router();
const crypto = require("crypto");

const { gerarSlug } = require("./utils/slug");
const { signInWithPassword } = require("./utils/firebaseAuthRest");

// IMPORTA DEPENDÊNCIAS QUE JÁ EXISTEM NO SERVER
module.exports = ({
  db,
  auth,
  FieldValue,
  Timestamp,
  AggregateField,
  verificarToken,
  verificarCSRF,
  verificarSuperAdmin,
  upload,
  schemaProduto,
  validarBuffer,
  uploadCloudinary,
  cloudinary,
  loginLimiter,
  logger,
}) => {
  // Helper: calcula o campo "esgotado" que antes vinha de um CASE WHEN no SQL
  function comEsgotado(data) {
    const esgotado =
      data.controla_estoque === true && Number(data.estoque) <= 0;
    return { ...data, esgotado };
  }

  // ================= ADMIN =================

  router.post(
    "/admin/register",
    verificarToken,
    verificarCSRF,
    verificarSuperAdmin,
    async (req, res) => {
      const { email, senha, role, establishmentName } = req.body;
      const normalizedRole = role ? String(role).trim().toLowerCase() : "";

      if (!email || !senha || !normalizedRole) {
        return res.status(400).json({ mensagem: "Preencha todos os campos!" });
      }

      if (!["admin", "superadmin"].includes(normalizedRole)) {
        return res
          .status(400)
          .json({ mensagem: "Role inválido. Use admin ou superadmin." });
      }

      if (normalizedRole === "admin" && !establishmentName) {
        return res
          .status(400)
          .json({ mensagem: "Informe o nome do estabelecimento" });
      }

      try {
        let establishmentId = null;

        if (normalizedRole === "admin") {
          const slug = gerarSlug(establishmentName);

          const porNome = await db
            .collection("estabelecimentos")
            .where("nome", "==", establishmentName)
            .limit(1)
            .get();

          if (!porNome.empty) {
            establishmentId = porNome.docs[0].id;
          } else {
            const porSlug = await db
              .collection("estabelecimentos")
              .where("slug", "==", slug)
              .limit(1)
              .get();

            if (!porSlug.empty) {
              return res.status(400).json({
                mensagem:
                  "Já existe um estabelecimento com esse nome (slug duplicado)",
              });
            }

            const novoEstab = await db.collection("estabelecimentos").add({
              nome: establishmentName,
              slug,
              banner: null,
              telefone: null,
              chave_pix: null,
              horarios: null,
              cor_primaria: null,
              cor_secundaria: null,
              banner_public_id: null,
              created_at: FieldValue.serverTimestamp(),
            });

            establishmentId = novoEstab.id;
          }
        }

        // Quem gera e guarda o hash da senha agora é o próprio Firebase Auth
        let userRecord;
        try {
          userRecord = await auth.createUser({
            email,
            password: senha,
            disabled: false,
          });
        } catch (err) {
          if (err.code === "auth/email-already-exists") {
            return res
              .status(400)
              .json({ mensagem: "Já existe um admin com esse email" });
          }
          throw err;
        }

        await db.collection("admin").doc(userRecord.uid).set({
          email,
          role: normalizedRole,
          establishment_id: establishmentId,
          active: true,
          deactivated_at: null,
          tentativas_login: 0,
          bloqueado: false,
          primeiro_login: false,
          created_at: FieldValue.serverTimestamp(),
        });

        res.json({ mensagem: "Admin criado!" });
      } catch (error) {
        logger.error("Erro ao criar admin", error);
        res.status(500).json({ mensagem: "Erro no servidor" });
      }
    },
  );

  router.post("/admin/login", loginLimiter, async (req, res) => {
    const { email, senha } = req.body;

    if (!email || !senha) {
      return res.status(400).json({ mensagem: "Preencha todos os campos!" });
    }

    try {
      const snap = await db
        .collection("admin")
        .where("email", "==", email)
        .limit(1)
        .get();

      if (snap.empty) {
        return res.status(401).json({ mensagem: "Email ou Senha incorreto!" });
      }

      const adminDoc = snap.docs[0];
      const admin = adminDoc.data();

      if (admin.bloqueado) {
        return res.status(403).json({
          mensagem: "Conta bloqueada. Entre em contato com o suporte.",
        });
      }

      // Quem valida a senha agora é o Firebase Auth (via REST), não o bcrypt local
      let signInResult;
      try {
        signInResult = await signInWithPassword(email, senha);
      } catch (err) {
        const tentativas = (admin.tentativas_login || 0) + 1;

        if (tentativas >= 5) {
          await adminDoc.ref.update({
            tentativas_login: tentativas,
            bloqueado: true,
          });

          return res.status(403).json({
            mensagem: "Conta bloqueada após várias tentativas.",
          });
        }

        await adminDoc.ref.update({ tentativas_login: tentativas });

        return res.status(401).json({
          mensagem: "Email ou senha incorretos",
        });
      }

      await adminDoc.ref.update({ tentativas_login: 0 });

      if (admin.active !== true) {
        return res.status(403).json({ mensagem: "Conta desativada" });
      }

      const tokenMaxAge =
        Number(process.env.SESSION_MAX_AGE_MS) || 1000 * 60 * 60 * 8; // 8 horas por padrão

      // Troca o idToken (curta duração) por um Session Cookie de longa duração,
      // que é o que efetivamente guardamos no cookie httpOnly "token".
      const sessionCookie = await auth.createSessionCookie(
        signInResult.idToken,
        {
          expiresIn: tokenMaxAge,
        },
      );

      const csrfToken = crypto.randomBytes(32).toString("hex");

      res.cookie("token", sessionCookie, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "strict",
        maxAge: tokenMaxAge,
      });

      res.cookie("csrf-token", csrfToken, {
        httpOnly: false,
        secure: process.env.NODE_ENV === "production",
        sameSite: "strict",
        maxAge: tokenMaxAge,
      });

      let establishmentName = null;

      if (admin.establishment_id) {
        const estabDoc = await db
          .collection("estabelecimentos")
          .doc(admin.establishment_id)
          .get();

        if (estabDoc.exists) {
          establishmentName = estabDoc.data().nome;
        }
      }

      return res.json({
        mensagem: "Login sucesso",
        role: admin.role,
        establishmentId: admin.establishment_id || null,
        establishmentName,
        primeiroLogin: admin.primeiro_login === true,
      });
    } catch (error) {
      logger.error("Erro ao fazer login", error);
      return res.status(500).json({ mensagem: "Erro no servidor" });
    }
  });

  router.post("/admin/logout", async (req, res) => {
    const sessionCookie = req.cookies.token;

    if (sessionCookie) {
      try {
        const decoded = await auth.verifySessionCookie(sessionCookie);
        await auth.revokeRefreshTokens(decoded.uid);
      } catch (err) {
        // cookie já inválido/expirado — não é um erro relevante aqui
      }
    }

    res.clearCookie("token", {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
    });

    res.clearCookie("csrf-token", {
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
    });

    return res.json({ mensagem: "Logout realizado com sucesso" });
  });

  router.get("/admin/me", verificarToken, verificarCSRF, (req, res) => {
    res.json({
      id: req.user.id,
      role: req.user.role,
      establishmentId: req.user.establishmentId,
    });
  });

  router.put(
    "/admin/desbloquear/:id",
    verificarToken,
    verificarCSRF,
    verificarSuperAdmin,
    async (req, res) => {
      const { id } = req.params;

      try {
        await db
          .collection("admin")
          .doc(id)
          .update({ bloqueado: false, tentativas_login: 0 });

        res.json({ mensagem: "Conta desbloqueada com sucesso" });
      } catch (err) {
        logger.error("Erro ao desbloquear", err);
        res.status(500).json({ mensagem: "Erro ao desbloquear" });
      }
    },
  );

  router.put(
    "/auth/primeiro-acesso",
    verificarToken,
    verificarCSRF,
    async (req, res) => {
      try {
        const { novaSenha } = req.body;
        const userId = req.user.id;

        if (!novaSenha) {
          return res.status(400).json({
            mensagem: "Nova senha obrigatória",
          });
        }

        await auth.updateUser(userId, { password: novaSenha });

        await db.collection("admin").doc(userId).update({
          primeiro_login: false,
        });

        res.json({
          mensagem: "Senha atualizada com sucesso",
        });
      } catch (err) {
        logger.error("Erro ao trocar senha", err);

        res.status(500).json({
          mensagem: "Erro no servidor",
        });
      }
    },
  );

  router.get("/admin/check-token", verificarToken, (req, res) => {
    res.json({ valid: true, user: req.user });
  });

  router.get(
    "/admin/list",
    verificarToken,
    verificarSuperAdmin,
    async (req, res) => {
      try {
        // Equivalente ao "DELETE FROM admin WHERE active = 0 AND deactivated_at < ..."
        // Requer índice composto (active, deactivated_at) no Firestore.
        const cutoff = Timestamp.fromMillis(
          Date.now() - 7 * 24 * 60 * 60 * 1000,
        );

        const expirados = await db
          .collection("admin")
          .where("active", "==", false)
          .where("deactivated_at", "<", cutoff)
          .get();

        await Promise.all(
          expirados.docs.map(async (doc) => {
            try {
              await auth.deleteUser(doc.id);
            } catch (err) {
              logger.error(`Erro ao remover usuário do Auth (${doc.id})`, err);
            }
            await doc.ref.delete();
          }),
        );

        // Firestore não tem JOIN — busca os admins e resolve o nome do
        // estabelecimento de cada um separadamente (com cache simples).
        const snap = await db.collection("admin").get();
        const estabCache = new Map();

        const admins = await Promise.all(
          snap.docs.map(async (doc) => {
            const data = doc.data();
            let establishment_name = null;

            if (data.establishment_id) {
              if (!estabCache.has(data.establishment_id)) {
                const estabDoc = await db
                  .collection("estabelecimentos")
                  .doc(data.establishment_id)
                  .get();

                estabCache.set(
                  data.establishment_id,
                  estabDoc.exists ? estabDoc.data().nome : null,
                );
              }

              establishment_name = estabCache.get(data.establishment_id);
            }

            return {
              id: doc.id,
              email: data.email,
              role: data.role,
              active: data.active,
              bloqueado: data.bloqueado,
              tentativas_login: data.tentativas_login,
              deactivated_at: data.deactivated_at
                ? data.deactivated_at.toDate()
                : null,
              establishment_name,
            };
          }),
        );

        res.json({ admins });
      } catch (err) {
        logger.error("Erro ao carregar admins", err);
        res.status(500).json({ mensagem: "Erro ao carregar admins" });
      }
    },
  );

  router.patch(
    "/admin/:id/status",
    verificarToken,
    verificarCSRF,
    verificarSuperAdmin,
    async (req, res) => {
      const { id } = req.params;
      const { active } = req.body;

      if (typeof active !== "boolean") {
        return res.status(400).json({ mensagem: "Valor 'active' inválido" });
      }

      try {
        const ref = db.collection("admin").doc(id);
        const doc = await ref.get();

        if (!doc.exists) {
          return res.status(404).json({ mensagem: "Admin não encontrado" });
        }

        await ref.update({
          active,
          deactivated_at: active ? null : FieldValue.serverTimestamp(),
        });

        // Desativa também no Firebase Auth, pra impedir login mesmo que
        // alguém ainda tenha um idToken válido por aí.
        await auth.updateUser(id, { disabled: !active });

        res.json({ mensagem: "Status atualizado com sucesso" });
      } catch (err) {
        logger.error("Erro ao atualizar status do admin", err);
        res.status(500).json({ mensagem: "Erro ao atualizar status do admin" });
      }
    },
  );

  router.put(
    "/admin/:id/reset-password",
    verificarToken,
    verificarCSRF,
    verificarSuperAdmin,
    async (req, res) => {
      const { id } = req.params;
      const { senha } = req.body;

      if (!senha || typeof senha !== "string" || senha.trim().length < 8) {
        return res.status(400).json({
          mensagem: "Senha obrigatória com ao menos 8 caracteres.",
        });
      }

      try {
        const ref = db.collection("admin").doc(id);
        const doc = await ref.get();

        if (!doc.exists) {
          return res.status(404).json({ mensagem: "Admin não encontrado" });
        }

        await auth.updateUser(id, { password: senha.trim() });
        await ref.update({ primeiro_login: true });

        res.json({
          mensagem:
            "Senha redefinida com sucesso. Esse admin será redirecionado para trocar a senha no próximo login.",
        });
      } catch (error) {
        logger.error("Erro ao redefinir senha", error);
        res.status(500).json({ mensagem: "Erro ao redefinir senha" });
      }
    },
  );

  // ================= ESTABELECIMENTOS =================

  router.get("/estabelecimentos", async (req, res) => {
    const { slug } = req.query;

    try {
      const snap = await db
        .collection("estabelecimentos")
        .where("slug", "==", slug)
        .limit(1)
        .get();

      if (snap.empty) {
        return res.status(404).json({ mensagem: "Não encontrado" });
      }

      const doc = snap.docs[0];
      res.json({ id: doc.id, ...doc.data() });
    } catch (err) {
      res.status(500).json(err);
    }
  });

  router.get("/estabelecimentos/:id", async (req, res) => {
    const { id } = req.params;

    try {
      const doc = await db.collection("estabelecimentos").doc(id).get();

      if (!doc.exists) {
        return res
          .status(404)
          .json({ mensagem: "Estabelecimento não encontrado" });
      }

      const { nome, slug, banner } = doc.data();
      res.json({ id: doc.id, nome, slug, banner });
    } catch (err) {
      res.status(500).json(err);
    }
  });

  router.put(
    "/estabelecimentos/:id/banner",
    verificarToken,
    verificarCSRF,
    upload.single("banner"),
    async (req, res) => {
      try {
        const { id } = req.params;

        if (!req.file) {
          return res.status(400).json({ mensagem: "Nenhuma imagem enviada" });
        }

        await validarBuffer(req.file.buffer);

        const result = await uploadCloudinary(req.file.buffer);
        const novaUrl = result.secure_url;
        const novoPublicId = result.public_id;

        const ref = db.collection("estabelecimentos").doc(id);
        const doc = await ref.get();

        if (!doc.exists) {
          return res
            .status(404)
            .json({ mensagem: "Estabelecimento não encontrado" });
        }

        const publicIdAntigo = doc.data().banner_public_id;

        if (publicIdAntigo) {
          try {
            await cloudinary.uploader.destroy(publicIdAntigo);
            logger.info("Banner antigo deletado");
          } catch (e) {
            logger.error("Erro ao deletar banner antigo", e);
          }
        }

        await ref.update({ banner: novaUrl, banner_public_id: novoPublicId });

        res.json({
          mensagem: "Banner atualizado com sucesso!",
          banner: novaUrl,
        });
      } catch (err) {
        logger.error("Erro ao atualizar banner", err);
        res.status(err.statusCode || 500).json({
          erro: err.message || "Erro no servidor",
        });
      }
    },
  );

  router.put(
    "/estabelecimentos/:id/horarios",
    verificarToken,
    verificarCSRF,
    async (req, res) => {
      const { id } = req.params;
      let { horarios } = req.body;

      Object.keys(horarios || {}).forEach((dia) => {
        if (horarios[dia]) {
          horarios[dia] = {
            abertura: horarios[dia].abertura,
            fechamento:
              horarios[dia].fechamento || horarios[dia]["f echamento"] || null,
          };
        }
      });

      try {
        // Firestore guarda objetos nativamente — não precisa mais de JSON.stringify
        await db.collection("estabelecimentos").doc(id).update({ horarios });
        res.json({ mensagem: "Horários atualizados!" });
      } catch (err) {
        res.status(500).json(err);
      }
    },
  );

  router.get("/estabelecimentos/:id/horarios", async (req, res) => {
    const { id } = req.params;

    try {
      const doc = await db.collection("estabelecimentos").doc(id).get();

      if (!doc.exists) {
        return res.json({ horarios: {} });
      }

      res.json({ horarios: doc.data().horarios || {} });
    } catch (err) {
      logger.error("Erro ao buscar horários", err);
      res.status(500).json({ mensagem: "Erro ao buscar horários" });
    }
  });

  router.put(
    "/estabelecimentos/:id/dados",
    verificarToken,
    verificarCSRF,
    async (req, res) => {
      const { id } = req.params;
      const { telefone } = req.body;

      try {
        await db.collection("estabelecimentos").doc(id).update({ telefone });
        res.json({ mensagem: "Dados atualizados com sucesso!" });
      } catch (err) {
        logger.error("Erro ao atualizar dados", err);
        res.status(500).json(err);
      }
    },
  );

  router.get(
    "/admin/me/estabelecimento",
    verificarToken,
    verificarCSRF,
    async (req, res) => {
      try {
        const adminDoc = await db.collection("admin").doc(req.user.id).get();

        if (!adminDoc.exists || !adminDoc.data().establishment_id) {
          return res
            .status(404)
            .json({ mensagem: "Estabelecimento não encontrado" });
        }

        const estabDoc = await db
          .collection("estabelecimentos")
          .doc(adminDoc.data().establishment_id)
          .get();

        if (!estabDoc.exists) {
          return res
            .status(404)
            .json({ mensagem: "Estabelecimento não encontrado" });
        }

        const { nome, slug, telefone } = estabDoc.data();
        res.json({ nome, slug, telefone });
      } catch (err) {
        res.status(500).json(err);
      }
    },
  );

  // ================= PRODUTOS =================

  router.get("/produtos", async (req, res) => {
    const { slug } = req.query;

    if (!slug) {
      return res.status(400).json({ error: "Slug obrigatório" });
    }

    try {
      const estabSnap = await db
        .collection("estabelecimentos")
        .where("slug", "==", slug)
        .limit(1)
        .get();

      if (estabSnap.empty) {
        return res
          .status(404)
          .json({ error: "Estabelecimento não encontrado" });
      }

      const establishmentId = estabSnap.docs[0].id;

      const produtosSnap = await db
        .collection("produtos")
        .where("establishment_id", "==", establishmentId)
        .get();

      const produtos = produtosSnap.docs.map((doc) =>
        comEsgotado({ id: doc.id, ...doc.data() }),
      );

      res.json(produtos);
    } catch (err) {
      res.status(500).json({ error: "Erro ao buscar produtos" });
    }
  });

  router.get(
    "/me/produtos",
    verificarToken,
    verificarCSRF,
    async (req, res) => {
      try {
        const establishmentId = req.user.establishmentId;

        let snap;

        if (req.user.role === "superadmin") {
          snap = await db.collection("produtos").get();
        } else {
          if (!establishmentId) {
            return res.status(400).json({
              mensagem: "Admin sem estabelecimento associado",
            });
          }

          snap = await db
            .collection("produtos")
            .where("establishment_id", "==", establishmentId)
            .get();
        }

        const produtos = snap.docs.map((doc) =>
          comEsgotado({ id: doc.id, ...doc.data() }),
        );

        res.json(produtos);
      } catch (err) {
        res.status(500).json(err);
      }
    },
  );

  router.post(
    "/me/produtos",
    verificarToken,
    verificarCSRF,
    upload.single("imagem"),
    async (req, res) => {
      try {
        const { error, value } = schemaProduto.validate(req.body);

        if (error) {
          return res.status(400).json({
            erro: error.details[0].message,
          });
        }

        if (!req.file) {
          return res.status(400).json({ erro: "Imagem obrigatória" });
        }

        await validarBuffer(req.file.buffer);

        const result = await uploadCloudinary(req.file.buffer);

        const imagemUrl = result.secure_url;
        const imagemPublicId = result.public_id;

        const { nome, descricao, categoria, preco, controla_estoque, estoque } =
          value;

        const controlaEstoque =
          controla_estoque === true || controla_estoque === "true";

        const estoqueFinal = controlaEstoque ? Number(estoque ?? 0) : null;

        if (
          controlaEstoque &&
          (estoqueFinal === null || isNaN(estoqueFinal) || estoqueFinal < 0)
        ) {
          return res.status(400).json({
            erro: "Estoque inválido",
          });
        }

        const establishmentId = req.user.establishmentId;

        await db.collection("produtos").add({
          nome,
          descricao,
          categoria,
          preco,
          imagem: imagemUrl,
          imagem_public_id: imagemPublicId,
          establishment_id: establishmentId,
          controla_estoque: controlaEstoque,
          estoque: estoqueFinal,
          estoque_reservado: 0,
          created_at: FieldValue.serverTimestamp(),
          updated_at: FieldValue.serverTimestamp(),
        });

        res.status(201).json({
          mensagem: "Produto adicionado com sucesso!",
          imagem: imagemUrl,
        });
      } catch (err) {
        logger.error("Erro na criação de produto", err);

        res.status(err.statusCode || 500).json({
          erro: err.message || "Erro no servidor",
        });
      }
    },
  );

  router.put(
    "/produtos/:id",
    verificarToken,
    verificarCSRF,
    upload.single("imagem"),
    async (req, res) => {
      try {
        const id = req.params.id;

        req.body.controla_estoque = req.body.controla_estoque === "true";

        const { nome, descricao, categoria, preco, estoque, controla_estoque } =
          req.body;

        const controlaEstoque = controla_estoque;

        let imagemUrl = null;
        let imagemPublicId = null;

        if (req.file) {
          await validarBuffer(req.file.buffer);

          const result = await uploadCloudinary(req.file.buffer);

          imagemUrl = result.secure_url;
          imagemPublicId = result.public_id;
        }

        if (!nome || !descricao || !categoria || !preco) {
          return res.status(400).json({
            erro: "Nome, descrição, categoria e preço são obrigatórios!",
          });
        }

        const estoqueFinal = controlaEstoque ? Number(estoque ?? 0) : null;

        if (controlaEstoque && (isNaN(estoqueFinal) || estoqueFinal < 0)) {
          return res.status(400).json({
            erro: "Estoque inválido",
          });
        }

        const ref = db.collection("produtos").doc(id);
        const doc = await ref.get();

        if (!doc.exists) {
          return res.status(404).json({ erro: "Produto não encontrado" });
        }

        const produto = doc.data();
        const establishmentId = req.user.establishmentId;

        if (
          req.user.role !== "superadmin" &&
          produto.establishment_id !== establishmentId
        ) {
          return res.status(403).json({ mensagem: "Acesso negado" });
        }

        const imagemPublicIdAntigo = produto.imagem_public_id;

        if (imagemUrl && imagemPublicIdAntigo) {
          try {
            await cloudinary.uploader.destroy(imagemPublicIdAntigo);
          } catch (e) {
            logger.error("Erro ao deletar imagem antiga", e);
          }
        }

        const imagemParaSalvar = imagemUrl || produto.imagem;
        const publicIdParaSalvar = imagemPublicId || imagemPublicIdAntigo;

        await ref.update({
          nome,
          descricao,
          categoria,
          preco,
          estoque: estoqueFinal,
          controla_estoque: controlaEstoque,
          imagem: imagemParaSalvar,
          imagem_public_id: publicIdParaSalvar,
          updated_at: FieldValue.serverTimestamp(),
        });

        res.json({
          mensagem: "Produto atualizado com sucesso",
          imagem: imagemParaSalvar,
        });
      } catch (err) {
        logger.error("Erro ao atualizar produto", err);
        res.status(500).json({ erro: err.message });
      }
    },
  );

  router.delete(
    "/produtos/:id",
    verificarToken,
    verificarCSRF,
    async (req, res) => {
      const id = req.params.id;

      try {
        const ref = db.collection("produtos").doc(id);
        const doc = await ref.get();

        if (!doc.exists) {
          return res.status(404).json({ mensagem: "Produto não encontrado" });
        }

        const produto = doc.data();
        const establishmentId = req.user.establishmentId;

        if (
          req.user.role !== "superadmin" &&
          produto.establishment_id !== establishmentId
        ) {
          return res.status(403).json({ mensagem: "Acesso negado" });
        }

        if (produto.imagem_public_id) {
          try {
            await cloudinary.uploader.destroy(produto.imagem_public_id);
          } catch (err) {
            logger.error("Erro ao deletar imagem", err);
          }
        }

        await ref.delete();

        res.json({ mensagem: "Produto deletado com sucesso" });
      } catch (err) {
        res.status(500).json(err);
      }
    },
  );

  router.patch(
    "/produtos/:id/estoque",
    verificarToken,
    verificarCSRF,
    async (req, res) => {
      const { id } = req.params;
      const estoque = Number(req.body.estoque);

      if (estoque === undefined || isNaN(estoque)) {
        return res.status(400).json({ mensagem: "Estoque inválido" });
      }

      try {
        const ref = db.collection("produtos").doc(id);
        const doc = await ref.get();

        if (!doc.exists) {
          return res.status(404).json({ mensagem: "Produto não encontrado" });
        }

        const produto = doc.data();

        if (
          req.user.role !== "superadmin" &&
          produto.establishment_id !== req.user.establishmentId
        ) {
          return res.status(403).json({ mensagem: "Acesso negado" });
        }

        await ref.update({ estoque });

        res.json({ mensagem: "Estoque atualizado com sucesso" });
      } catch (err) {
        res.status(500).json(err);
      }
    },
  );

  router.patch(
    "/produtos/:id/estoque/add",
    verificarToken,
    verificarCSRF,
    async (req, res) => {
      const { id } = req.params;
      const quantidade = Number(req.body.quantidade);

      if (quantidade === undefined || isNaN(quantidade)) {
        return res.status(400).json({ mensagem: "Estoque inválido" });
      }

      try {
        const ref = db.collection("produtos").doc(id);
        const doc = await ref.get();

        if (!doc.exists) {
          return res.status(404).json({ mensagem: "Produto não encontrado" });
        }

        const produto = doc.data();

        if (
          req.user.role !== "superadmin" &&
          produto.establishment_id !== req.user.establishmentId
        ) {
          return res.status(403).json({ mensagem: "Acesso negado" });
        }

        await ref.update({ estoque: FieldValue.increment(quantidade) });

        const atualizado = await ref.get();

        res.json({
          mensagem: "Estoque adicionado",
          estoque: atualizado.data().estoque,
        });
      } catch (err) {
        res.status(500).json(err);
      }
    },
  );

  router.patch(
    "/produtos/:id/estoque/remove",
    verificarToken,
    verificarCSRF,
    async (req, res) => {
      const { id } = req.params;
      const quantidade = Number(req.body.quantidade);

      if (!quantidade || quantidade <= 0) {
        return res.status(400).json({ mensagem: "Quantidade inválida" });
      }

      try {
        const ref = db.collection("produtos").doc(id);

        // Transação garante que duas requisições simultâneas não deixem o
        // estoque negativo (a verificação e a escrita acontecem atomicamente).
        const novoEstoque = await db.runTransaction(async (tx) => {
          const doc = await tx.get(ref);

          if (!doc.exists) {
            const err = new Error("Produto não encontrado");
            err.statusCode = 404;
            throw err;
          }

          const produto = doc.data();

          if (
            req.user.role !== "superadmin" &&
            produto.establishment_id !== req.user.establishmentId
          ) {
            const err = new Error("Acesso negado");
            err.statusCode = 403;
            throw err;
          }

          const estoqueAtual = Number(produto.estoque) || 0;

          if (estoqueAtual < quantidade) {
            const err = new Error("Estoque insuficiente");
            err.statusCode = 400;
            throw err;
          }

          const novo = estoqueAtual - quantidade;
          tx.update(ref, { estoque: novo });
          return novo;
        });

        res.json({ mensagem: "Estoque reduzido", estoque: novoEstoque });
      } catch (err) {
        res
          .status(err.statusCode || 500)
          .json({ mensagem: err.message || "Erro no servidor" });
      }
    },
  );

  router.patch(
    "/produtos/:id/controle-estoque",
    verificarToken,
    verificarCSRF,
    async (req, res) => {
      const { id } = req.params;
      const { controla_estoque } = req.body;

      try {
        const ref = db.collection("produtos").doc(id);
        const doc = await ref.get();

        if (!doc.exists) {
          return res.status(404).json({ mensagem: "Produto não encontrado" });
        }

        const produto = doc.data();

        if (
          req.user.role !== "superadmin" &&
          produto.establishment_id !== req.user.establishmentId
        ) {
          return res.status(403).json({ mensagem: "Acesso negado" });
        }

        await ref.update({ controla_estoque });

        res.json({
          mensagem: "Controle de estoque atualizado",
        });
      } catch (err) {
        res.status(500).json(err);
      }
    },
  );

  // ================= PEDIDOS =================

  router.post("/pedidos", async (req, res) => {
    const { itens } = req.body;

    if (!itens || itens.length === 0) {
      return res.status(400).json({ mensagem: "Pedido vazio" });
    }

    try {
      const refs = itens.map((item) =>
        db.collection("produtos").doc(String(item.id)),
      );
      const docs = await db.getAll(...refs);

      let total = 0;
      const detalhes = [];

      for (let i = 0; i < itens.length; i++) {
        const item = itens[i];
        const doc = docs[i];

        if (!doc.exists) {
          return res.status(400).json({ mensagem: "Produto inválido" });
        }

        const produto = doc.data();
        const subtotal = produto.preco * item.quantidade;
        total += subtotal;

        detalhes.push({
          nome: produto.nome,
          quantidade: item.quantidade,
          preco: produto.preco,
          subtotal,
        });
      }

      res.json({ total, itens: detalhes });
    } catch (err) {
      logger.error("Erro ao calcular pedido", err);
      res.status(500).json({ mensagem: "Erro no servidor" });
    }
  });

  router.post("/pedidos/salvar", async (req, res) => {
    const {
      slug,
      itens,
      forma_pagamento,
      tipo_entrega,
      mesa,
      nome_cliente,
      endereco,
    } = req.body;

    if (!slug || !itens?.length) {
      return res.status(400).json({ mensagem: "Dados inválidos" });
    }

    try {
      const estabSnap = await db
        .collection("estabelecimentos")
        .where("slug", "==", slug)
        .limit(1)
        .get();

      if (estabSnap.empty) {
        return res.status(404).json({
          mensagem: "Estabelecimento não encontrado",
        });
      }

      const establishmentId = estabSnap.docs[0].id;
      const pedidoRef = db.collection("pedidos").doc();

      const { total, itensFinal } = await db.runTransaction(async (tx) => {
        const refs = itens.map((item) =>
          db.collection("produtos").doc(String(item.id)),
        );
        const docs = await Promise.all(refs.map((ref) => tx.get(ref)));

        let total = 0;
        const itensFinal = [];

        for (let i = 0; i < itens.length; i++) {
          const item = itens[i];
          const doc = docs[i];

          if (!doc.exists) {
            const err = new Error("Produto inválido");
            err.statusCode = 400;
            throw err;
          }

          const produto = doc.data();
          const subtotal = produto.preco * item.quantidade;
          total += subtotal;

          itensFinal.push({
            id: doc.id,
            nome: produto.nome,
            preco: produto.preco,
            quantidade: item.quantidade,
            subtotal,
          });

          if (produto.controla_estoque === true) {
            const disponivel =
              (Number(produto.estoque) || 0) -
              (Number(produto.estoque_reservado) || 0);

            if (disponivel < item.quantidade) {
              const err = new Error(
                `Estoque insuficiente para ${produto.nome}`,
              );
              err.statusCode = 400;
              throw err;
            }

            tx.update(refs[i], {
              estoque_reservado: FieldValue.increment(item.quantidade),
            });
          }
        }

        tx.set(pedidoRef, {
          establishment_id: establishmentId,
          itens: itensFinal,
          total,
          forma_pagamento,
          tipo_entrega,
          mesa: mesa || null,
          nome_cliente: nome_cliente || null,
          endereco: endereco || null,
          status: "pendente",
          created_at: FieldValue.serverTimestamp(),
        });

        return { total, itensFinal };
      });

      const io = req.app.get("io");

      if (io) {
        io.to(`estab_${establishmentId}`).emit("novoPedido", {
          pedido_id: pedidoRef.id,
          establishment_id: establishmentId,
          itens: itensFinal,
          total,
          nome_cliente,
          tipo_entrega,
          mesa,
        });
      }

      res.json({
        mensagem: "Pedido salvo com sucesso",
        pedido_id: pedidoRef.id,
        total,
        itens: itensFinal,
      });
    } catch (err) {
      logger.error("Erro ao salvar pedido", err);
      res
        .status(err.statusCode || 500)
        .json({ mensagem: err.message || "Erro ao salvar pedido" });
    }
  });

  router.get(
    "/admin/pedidos",
    verificarToken,
    verificarCSRF,
    async (req, res) => {
      try {
        const establishmentId = req.user.establishmentId;

        // Requer índice composto: establishment_id (==) + status (==) + created_at (desc)
        const snap = await db
          .collection("pedidos")
          .where("establishment_id", "==", establishmentId)
          .where("status", "==", "pendente")
          .orderBy("created_at", "desc")
          .get();

        const pedidos = snap.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
        res.json(pedidos);
      } catch (err) {
        logger.error("Erro ao buscar pedidos", err);
        res.status(500).json({ mensagem: "Erro ao buscar pedidos" });
      }
    },
  );

  router.delete(
    "/admin/pedidos/:id",
    verificarToken,
    verificarCSRF,
    async (req, res) => {
      const { id } = req.params;
      const establishmentId = req.user.establishmentId;

      try {
        await db.runTransaction(async (tx) => {
          const pedidoRef = db.collection("pedidos").doc(id);
          const pedidoDoc = await tx.get(pedidoRef);

          if (
            !pedidoDoc.exists ||
            pedidoDoc.data().establishment_id !== establishmentId
          ) {
            const err = new Error("Pedido não encontrado");
            err.statusCode = 404;
            throw err;
          }

          const itens = pedidoDoc.data().itens || [];
          const produtoRefs = itens.map((item) =>
            db.collection("produtos").doc(String(item.id)),
          );
          const produtoDocs = await Promise.all(
            produtoRefs.map((ref) => tx.get(ref)),
          );

          for (let i = 0; i < itens.length; i++) {
            const item = itens[i];
            const produtoDoc = produtoDocs[i];

            if (!produtoDoc.exists) continue;

            const produto = produtoDoc.data();

            if (produto.establishment_id !== establishmentId) continue;

            if (produto.controla_estoque === true) {
              const reservadoAtual = Number(produto.estoque_reservado) || 0;
              const novoReservado = Math.max(
                reservadoAtual - item.quantidade,
                0,
              );

              tx.update(produtoRefs[i], { estoque_reservado: novoReservado });
            }
          }

          tx.delete(pedidoRef);
        });

        res.json({
          mensagem: "Pedido excluído e estoque corrigido!",
        });
      } catch (err) {
        logger.error("Erro ao excluir pedido", err);
        res
          .status(err.statusCode || 500)
          .json({ mensagem: err.message || "Erro ao excluir pedido" });
      }
    },
  );

  router.put(
    "/admin/pedidos/:id/finalizar",
    verificarToken,
    verificarCSRF,
    async (req, res) => {
      const pedidoId = req.params.id;
      const establishmentId = req.user.establishmentId;

      logger.info(
        `[FINALIZAR] Iniciando finalização do pedido ${pedidoId} para establishment ${establishmentId}`,
      );

      try {
        const historicoRef = db.collection("historico_pedidos").doc();

        await db.runTransaction(async (tx) => {
          const pedidoRef = db.collection("pedidos").doc(pedidoId);
          const pedidoDoc = await tx.get(pedidoRef);

          if (
            !pedidoDoc.exists ||
            pedidoDoc.data().establishment_id !== establishmentId ||
            pedidoDoc.data().status !== "pendente"
          ) {
            const err = new Error("Pedido não encontrado");
            err.statusCode = 404;
            throw err;
          }

          const pedido = pedidoDoc.data();
          const itens = pedido.itens || [];

          const produtoRefs = itens.map((item) =>
            db.collection("produtos").doc(String(item.id)),
          );
          const produtoDocs = await Promise.all(
            produtoRefs.map((ref) => tx.get(ref)),
          );

          // ================= VALIDAR ESTOQUE =================
          for (let i = 0; i < itens.length; i++) {
            const item = itens[i];
            const produtoDoc = produtoDocs[i];

            if (!produtoDoc.exists) {
              const err = new Error("Produto não encontrado");
              err.statusCode = 400;
              throw err;
            }

            const produto = produtoDoc.data();

            if (produto.controla_estoque !== true) continue;

            const estoque = Number(produto.estoque) || 0;
            const reservado = Number(produto.estoque_reservado) || 0;
            const disponivel = estoque - reservado + item.quantidade;

            if (disponivel < item.quantidade) {
              const err = new Error(`Estoque insuficiente para ${item.nome}`);
              err.statusCode = 400;
              throw err;
            }
          }

          // ================= BAIXAR ESTOQUE =================
          for (let i = 0; i < itens.length; i++) {
            const item = itens[i];
            const produto = produtoDocs[i].data();

            if (produto.controla_estoque === true) {
              tx.update(produtoRefs[i], {
                estoque: FieldValue.increment(-item.quantidade),
                estoque_reservado: FieldValue.increment(-item.quantidade),
              });
            }
          }

          // ================= HISTÓRICO =================
          logger.info(
            `[FINALIZAR] Inserindo pedido ${pedidoId} no histórico com valor ${pedido.total}`,
          );

          tx.set(historicoRef, {
            pedido_id: pedidoId,
            establishment_id: pedido.establishment_id,
            itens,
            total: pedido.total,
            forma_pagamento: pedido.forma_pagamento,
            tipo_entrega: pedido.tipo_entrega,
            mesa: pedido.mesa,
            nome_cliente: pedido.nome_cliente,
            endereco: pedido.endereco,
            finalizado_at: FieldValue.serverTimestamp(),
          });

          // ================= DELETE PEDIDO =================
          logger.info(
            `[FINALIZAR] Deletando pedido ${pedidoId} da coleção pedidos`,
          );

          tx.delete(pedidoRef);
        });

        logger.info(
          `[FINALIZAR] Pedido ${pedidoId} finalizado com sucesso e adicionado ao faturamento`,
        );

        res.json({
          mensagem: "Pedido finalizado com sucesso",
        });
      } catch (err) {
        logger.error("Erro ao finalizar pedido", err);

        res.status(err.statusCode || 500).json({
          mensagem: err.message || "Erro ao finalizar pedido",
        });
      }
    },
  );

  router.get(
    "/admin/historico",
    verificarToken,
    verificarCSRF,
    async (req, res) => {
      try {
        const establishmentId = req.user.establishmentId;

        const snap = await db
          .collection("historico_pedidos")
          .where("establishment_id", "==", establishmentId)
          .orderBy("finalizado_at", "desc")
          .get();

        const historico = snap.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));

        res.json(historico);
      } catch (err) {
        logger.error("Erro ao buscar histórico", err);
        res.status(500).json({ mensagem: "Erro ao buscar histórico" });
      }
    },
  );

  router.get(
    "/admin/faturamento",
    verificarToken,
    verificarCSRF,
    async (req, res) => {
      try {
        const establishmentId = req.user.establishmentId;

        logger.info(
          `[FATURAMENTO] Buscando faturamento para establishment ${establishmentId}`,
        );

        const { inicio, fim } = req.query;

        const baseQuery = db
          .collection("historico_pedidos")
          .where("establishment_id", "==", establishmentId);

        // Usa as aggregation queries nativas do Firestore (SUM no servidor),
        // em vez de baixar todos os documentos para somar no Node.
        const sumBetween = async (inicioTs, fimTs) => {
          let q = baseQuery;

          if (inicioTs) q = q.where("finalizado_at", ">=", inicioTs);
          if (fimTs) q = q.where("finalizado_at", "<=", fimTs);

          const snap = await q
            .aggregate({ total: AggregateField.sum("total") })
            .get();
          return snap.data().total || 0;
        };

        const agora = new Date();

        const inicioHoje = new Date(agora);
        inicioHoje.setHours(0, 0, 0, 0);

        const fimHoje = new Date(agora);
        fimHoje.setHours(23, 59, 59, 999);

        const seteDiasAtras = new Date(
          agora.getTime() - 7 * 24 * 60 * 60 * 1000,
        );

        const umMesAtras = new Date(agora);
        umMesAtras.setMonth(umMesAtras.getMonth() - 1);

        const totalPromise =
          inicio && fim
            ? sumBetween(
                Timestamp.fromDate(new Date(`${inicio}T00:00:00`)),
                Timestamp.fromDate(new Date(`${fim}T23:59:59`)),
              )
            : sumBetween(null, null);

        const [
          faturamento_total,
          faturamento_semana,
          faturamento_mes,
          faturamento_hoje,
        ] = await Promise.all([
          totalPromise,
          sumBetween(
            Timestamp.fromDate(seteDiasAtras),
            Timestamp.fromDate(agora),
          ),
          sumBetween(Timestamp.fromDate(umMesAtras), Timestamp.fromDate(agora)),
          sumBetween(
            Timestamp.fromDate(inicioHoje),
            Timestamp.fromDate(fimHoje),
          ),
        ]);

        logger.info(
          `[FATURAMENTO] Resultado - Hoje: ${faturamento_hoje}, Semana: ${faturamento_semana}, Mês: ${faturamento_mes}, Total: ${faturamento_total}`,
        );

        res.json({
          faturamento_total,
          faturamento_semana,
          faturamento_mes,
          faturamento_hoje,
        });
      } catch (error) {
        logger.error("Erro ao calcular faturamento", error);
        res.status(500).json({ mensagem: "Erro ao calcular faturamento" });
      }
    },
  );

  router.get(
    "/admin/pedidos-arquivados",
    verificarToken,
    verificarCSRF,
    async (req, res) => {
      try {
        const establishmentId = req.user.establishmentId;

        const snap = await db
          .collection("historico_pedidos_arquivados")
          .where("establishment_id", "==", establishmentId)
          .orderBy("arquivado_em", "desc")
          .get();

        const arquivados = snap.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));

        res.json(arquivados);
      } catch (error) {
        logger.error("Erro ao buscar pedidos arquivados", error);

        res.status(500).json({
          mensagem: "Erro ao buscar pedidos arquivados",
        });
      }
    },
  );

  return router;
};
