require("dotenv").config();

async function signInWithPassword(email, senha) {
  const apiKey = process.env.FIREBASE_WEB_API_KEY;

  if (!apiKey) {
    throw new Error("FIREBASE_WEB_API_KEY não foi configurada no .env");
  }

  const resposta = await fetch(
    `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${apiKey}`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        email,
        password: senha,
        returnSecureToken: true,
      }),
    },
  );

  const dados = await resposta.json();

  if (!resposta.ok) {
    const erro = new Error(
      dados?.error?.message || "Email ou senha incorretos",
    );

    erro.code = dados?.error?.message;
    throw erro;
  }

  return dados;
}

module.exports = { signInWithPassword };
