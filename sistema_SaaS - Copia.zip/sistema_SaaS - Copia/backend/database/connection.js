require("dotenv").config();

const { db, auth, FieldValue } = require("../config/firebase");

// Firestore é schemaless — não existe mais "CREATE TABLE" nem "ALTER TABLE ADD COLUMN".
// As coleções (admin, estabelecimentos, produtos, pedidos, historico_pedidos,
// historico_pedidos_arquivados) são criadas automaticamente no primeiro documento
// gravado em cada uma. Por isso esse arquivo ficou muito mais simples: a única
// responsabilidade que sobra aqui é garantir o superadmin padrão.

async function seedDefaultSuperAdmin() {
  const defaultEmail = process.env.DEFAULT_SUPERADMIN_EMAIL;
  const defaultPassword = process.env.DEFAULT_SUPERADMIN_PASSWORD;
  const defaultRole = process.env.DEFAULT_SUPERADMIN_ROLE;

  let userRecord = null;

  try {
    userRecord = await auth.getUserByEmail(defaultEmail);
  } catch (err) {
    if (err.code !== "auth/user-not-found") {
      throw err;
    }
  }

  // Usuário ainda não existe no Firebase Auth -> cria o usuário + o documento em /admin
  if (!userRecord) {
    userRecord = await auth.createUser({
      email: defaultEmail,
      password: defaultPassword,
      emailVerified: true,
      disabled: false,
    });

    await db.collection("admin").doc(userRecord.uid).set({
      email: defaultEmail,
      role: defaultRole,
      establishment_id: null,
      active: true,
      deactivated_at: null,
      tentativas_login: 0,
      bloqueado: false,
      primeiro_login: false,
      created_at: FieldValue.serverTimestamp(),
    });

    console.log(`Superadmin padrão '${defaultEmail}' criado e ativado.`);
    return;
  }

  // Usuário existe no Auth, mas por algum motivo não tem o documento no Firestore
  const adminDoc = await db.collection("admin").doc(userRecord.uid).get();

  if (!adminDoc.exists) {
    await db.collection("admin").doc(userRecord.uid).set({
      email: defaultEmail,
      role: defaultRole,
      establishment_id: null,
      active: true,
      deactivated_at: null,
      tentativas_login: 0,
      bloqueado: false,
      primeiro_login: false,
      created_at: FieldValue.serverTimestamp(),
    });

    console.log(
      `Documento Firestore do superadmin padrão '${defaultEmail}' recriado.`,
    );
    return;
  }

  // Existe e está desativado -> reativa
  if (adminDoc.data().active !== true) {
    await db.collection("admin").doc(userRecord.uid).update({
      active: true,
      deactivated_at: null,
    });

    if (userRecord.disabled) {
      await auth.updateUser(userRecord.uid, { disabled: false });
    }

    console.log(`Superadmin padrão '${defaultEmail}' reativado.`);
  }
}

async function initConnection() {
  // Mesma regra de antes: só semeia o superadmin padrão fora de produção,
  // ou se SEED_DEFAULT_SUPERADMIN=true for explicitamente setado.
  if (
    process.env.SEED_DEFAULT_SUPERADMIN === "true" ||
    process.env.NODE_ENV !== "production"
  ) {
    await seedDefaultSuperAdmin();
  }

  console.log("Firebase (Firestore + Auth) conectado com sucesso!");

  return { db, auth };
}

module.exports = initConnection();
